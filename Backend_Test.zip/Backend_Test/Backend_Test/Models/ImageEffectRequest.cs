﻿namespace Backend_Test
{
    public class ImageEffectRequest
    {
        public int ImageId { get; set; }
        public List<EffectType>? EffectType { get; set; }
        public int? Radius { get; set; }
        public int? Size { get; set; }
    }
}

