﻿using System;
namespace Backend_Test
{
    public class Image
    {
        public int Id { get; set; }
        public string Path { get; set; }
        public int? Size { get; set; }
        public int? Radius { get; set; }
        public List<EffectType>? EffectTypes { get; set;}

        public Image(int id, string path)
        {
            Id = id;
            Path = path;
        }
    }
}

