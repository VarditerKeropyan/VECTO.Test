﻿using System;
namespace Backend_Test
{
	public enum EffectType : byte
	{
		Effect1,
		Effect2,
		Effect3
	}
}

