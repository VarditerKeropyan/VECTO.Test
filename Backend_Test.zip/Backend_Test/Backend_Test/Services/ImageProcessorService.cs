﻿namespace Backend_Test
{
    public class ImageProcessorService : IImageProcessorService
    {
        public void ResizeImage(Image image, int size)
        {
            image.Size = size;
        }

        public void SetRadius(Image image, int radius)
        {
            image.Radius = radius;
        }

        public void SetEffect(Image image, List<EffectType> effectTypes)
        {
            image.EffectTypes = effectTypes;
        }

      
        public void ModifyImage(Image image, List<EffectType>? effectTypes, int? radius, int? size)
        {
            if (radius.HasValue)
            {
                SetRadius(image, radius.Value);
            }

            if (size.HasValue)
            {
                ResizeImage(image, size.Value);
            }

            if(effectTypes != null && effectTypes.Count() > 0)
            {
                SetEffect(image, effectTypes);
            }
        }
    }
}
