﻿using System;
namespace Backend_Test
{
	public interface IImageProcessorService
	{
        public void ModifyImage(Image image, List<EffectType>? effectTypes, int? radius, int? size);
    }
}

