﻿using Microsoft.AspNetCore.Mvc;
namespace Backend_Test
{
    [Route("api/[controller]")]
    [ApiController]
    public class ImageController : ControllerBase
    {
        private readonly IImageProcessorService imageProcessor;

        public ImageController(IImageProcessorService imageProcessor)
        {
            this.imageProcessor = imageProcessor;
        }

        [HttpPost("process-multiple-images")]
        public IActionResult ProcessMultipleImages([FromBody] List<ImageEffectRequest> imageEffectRequests)
        {
            if (imageEffectRequests == null || imageEffectRequests.Count == 0)
            {
                return BadRequest("ImageEffectRequests cannot be null or empty.");
            }

            foreach (var request in imageEffectRequests)
            {
                var image = new Image(request.ImageId, "path/to/image.jpg");
                imageProcessor.ModifyImage(image, request.EffectType, request.Radius, request.Size);
            }

            return Ok();
        }
    }
}
